import os

from dotenv import load_dotenv
from openai import OpenAI

_client = None
_DEFAULT_BASE_URL = "https://router.huggingface.co/v1"
_DEFAULT_MODEL = "HuggingFaceH4/zephyr-7b-beta:featherless-ai"


def get_client() -> OpenAI:
    global _client
    if _client is None:
        load_dotenv()
        api_key = os.getenv("HF_API_KEY")
        if not api_key:
            raise RuntimeError(
                "HF_API_KEY is not set. Set the environment variable before generating answers."
            )
        _client = OpenAI(
            base_url=os.getenv("HF_BASE_URL", _DEFAULT_BASE_URL),
            api_key=api_key,
        )
    return _client


def generate_answer(context, query):
    client = get_client()
    messages = [
        {
            "role": "system",
            "content": (
                "You are a RAG assistant.\n"
                "You MUST answer ONLY using the provided context.\n"
                "If the answer is present in the context, use it.\n"
                "Do not use outside knowledge.\n"
                "If the answer is not present, say 'I don't know'."
            ),
        },
        {
            "role": "user",
            "content": f"Context:\n{context}\n\nQuestion:\n{query}",
        },
    ]

    completion = client.chat.completions.create(
        model=os.getenv("HF_MODEL", _DEFAULT_MODEL),
        messages=messages,
        max_tokens=200,
        temperature=0.3,
        stream=True,
    )

    for chunk in completion:
        if len(chunk.choices) == 0:
            continue

        content = chunk.choices[0].delta.content if chunk.choices[0].delta else None
        if content:
            yield content
